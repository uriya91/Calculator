package com.example.classandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView result;
    double lastNum = 0;
    String currOperation = "";
    Boolean resultDisplayed = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        result = findViewById(R.id.calc_screen);
        result.setText("0");

    }


    public void pressNine(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("9");
        }
        else {
            result.append("9");
        }
    }

    public void pressEight(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("8");
        }
        else {
            result.append("8");
        }
        //char ch = button.getText().toString().charAt(0);
    }

    public void pressSeven(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("7");
        }
        else {
            result.append("7");
        }
    }

    public void pressSix(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("6");
        }
        else {
            result.append("6");
        }
    }

    public void pressFive(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("5");
        }
        else {
            result.append("5");
        }
    }

    public void pressFour(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("4");
        }
        else {
            result.append("4");
        }
    }

    public void pressThree(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("3");
        }
        else {
            result.append("3");
        }
    }

    public void pressTwo(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("2");
        }
        else {
            result.append("2");
        }
    }

    public void pressOne(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("1");
        }
        else {
            result.append("1");
        }
    }

    public void pressZero(View view) {
        Button button = ( Button ) view;
        if (resultDisplayed) {
            result.setText("");
            resultDisplayed = false;
        }
        if(result.getText().toString().equals("0")){
            result.setText("0");
        }
        else {
            result.append("0");
        }
    }

    public void pressC(View view) {
        Button button = ( Button ) view;
        result.setText("0");
        currOperation = "";
        lastNum = 0;
    }

    public void delete(View view) {
        if (resultDisplayed) {
            result.setText("0");
            resultDisplayed = false;
            return;
        }
        String num = result.getText().toString();
        if (num.equals("0") || num.length() == 1){
            result.setText(("0"));
        }
        else {
            result.setText(num.substring(0, num.length() - 1));
        }
    }

    public void percent(View view) {
        Button button = (Button) view;
        double currNum = Double.parseDouble(result.getText().toString());
        double percentVal = (lastNum* currNum) / 100;
        switch (currOperation){
            case "+":
                result.setText(String.valueOf(lastNum + percentVal));
                break;
            case "-":
                result.setText(String.valueOf(lastNum - percentVal));
                break;
            default:
                result.setText("Error");
        }
        resultDisplayed = true;
    }

    public void pressDot(View view) {
        Button button = ( Button ) view;

        if(result.getText().toString().equals("0")){
            result.setText("0.");
        }

        else if(result.getText().toString().contains(".")){

        }
        else {
            result.append(".");
        }
    }

    public void divide(View view) {
        Button button = (Button) view;
        lastNum = Double.parseDouble((result.getText().toString()));
        currOperation = button.getText().toString();
        result.setText("0");
    }

    public void multiply(View view) {
        Button button = (Button) view;
        lastNum = Double.parseDouble((result.getText().toString()));
        currOperation = button.getText().toString();
        result.setText("0");
    }

    public void subtraction(View view) {
        Button button = (Button) view;
        lastNum = Double.parseDouble((result.getText().toString()));
        currOperation = button.getText().toString();
        result.setText("0");
    }

    public void addition(View view) {
        Button button = (Button) view;
        lastNum = Double.parseDouble((result.getText().toString()));
        currOperation = button.getText().toString();
        result.setText("0");
    }

    public void equal(View view) {
        double currNum = Double.parseDouble(result.getText().toString());
        double resultNum = 0;

        switch (currOperation){
            case "/":
                if(currNum == 0){
                    result.setText("Error! canot divide by 0");
                    resultDisplayed = true;
                    return;
                }
                else{
                    resultNum = lastNum / currNum;
                    break;
                }
            case "X":
                resultNum = lastNum * currNum;
                break;
            case "-":
                resultNum = lastNum - currNum;
                break;
            case "+":
                resultNum = lastNum + currNum;
                break;
            default:
                result.setText("0");
                return;
        }
        result.setText(String.valueOf(resultNum));
        currOperation = "";
        lastNum = currNum;
        resultDisplayed = true;
    }
}











